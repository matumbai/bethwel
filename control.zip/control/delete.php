<?php 
    error_reporting(0);
    include('../auth/conn.php');
    $name = htmlentities(mysqli_real_escape_string($conn, $_POST['name']));
    $image = htmlentities(mysqli_real_escape_string($conn, $_POST['image']));
    // check if exists in orders
    $ord = "SELECT * FROM orders WHERE product='$name' AND status='paid' AND delivery='' 
        OR product='$name' AND status='' AND delivery=''";
    $result = mysqli_query($conn, $ord);
    $row = mysqli_num_rows($result);
    if(!$row>0){
        // delete image
        if(!empty($image)){
            unlink("../products/$image");
        }
        // delete record
        $sql = "DELETE FROM products WHERE product='$name'";
        $res = mysqli_query($conn, $sql);
        if($res){
            ?> <p class="text-success">Product deleted successfully!</p> <?php
        }
    }else{
        ?> <p class="text-danger" style="color: #FD0155;">This product exists in pending orders! <br> Please complete and try again</p> <?php
    }
?>