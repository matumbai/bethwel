<style>
    .text-danger{
        margin: 4px;
        color: #ff0080;
        text-align: center;
    }
</style>
<?php
    include('../auth/conn.php');
    $product = htmlentities(mysqli_real_escape_string($conn, $_POST['product']));
    $price = htmlentities(mysqli_real_escape_string($conn, $_POST['price']));
    $quantity = htmlentities(mysqli_real_escape_string($conn, $_POST['weight']));
    $images = htmlentities(mysqli_real_escape_string($conn, $_POST['images']));
    $items = htmlentities(mysqli_real_escape_string($conn, $_POST['stock']));
    $category = htmlentities(mysqli_real_escape_string($conn, $_POST['category']));
    $description = htmlentities(mysqli_real_escape_string($conn, $_POST['description']));
    if(!empty($product) && !empty($price) && !empty($quantity) && !empty($items) && !empty($category) && !empty($description)){
        
        // upload product
        if(!empty($_FILES["image"]["name"])){
            $fileInfo = PATHINFO($_FILES["image"]["name"]);
            if ($fileInfo['extension'] == "jpg" OR $fileInfo['extension'] == "png") {
                $newFilename = $fileInfo['filename'] . "_" . time() . "." . $fileInfo['extension'];
                move_uploaded_file($_FILES["image"]["tmp_name"], "../products/" . $newFilename);
                $image = htmlspecialchars(mysqli_real_escape_string($conn, $newFilename));
                unlink("../products/$images");
            }
        }else{
            $image = htmlspecialchars(mysqli_real_escape_string($conn, $images));
        }
        $sql = "UPDATE products SET product='$product',image='$image',category='$category',description='$description',
        price='$price',quantity='$quantity',items='$items' WHERE product='$product'";
        $result = mysqli_query($conn, $sql);
        if($result){
            ?> <p class="text-danger">Update successful!</p>
            <script> $('#edit-form').trigger('reset'); </script> <?php
        }
    }else{
        ?> <span class="text-danger">All fields must be filled!</span> <?php
    }
?>