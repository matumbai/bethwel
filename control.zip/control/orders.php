<?php 
    include('../auth/conn.php');
    $sql = "SELECT * FROM orders ORDER BY id DESC";
    $res = mysqli_query($conn, $sql);
    $row = mysqli_num_rows($res);
    if(!$row>0){
        ?> <p style="margin: 10px; text-align: center;">No results found!</p> <?php
    }else{
        while($row = mysqli_fetch_assoc($res)){
            $id = $row['id'];
            $product = $row['product'];
            $price = $row['price'];
            $quantity = $row['quantity'];
            $county = $row['county'];
            $location = $row['location'];
            $name = $row['name'];
            $phone = $row['phone'];
            $status = $row['status'];
            $delivery = $row['delivery'];
            ?> 
                <tr>
                    <td>
                        <?php echo $name ?>
                        <div class="tel">
                            Tel: <?php echo $phone ?>
                        </div>
                    </td>
                    <td>
                        <b><?php echo $product ?></b><br>
                        <span>Ksh: <?php echo $price*$quantity ?></span> 
                        <div class="store"> 
                            <span>Items: <?php echo $quantity ?></span>
                        </div>
                    </td>
                    <td>
                        <?php echo $county. " county,<br> ". $location; ?>
                    </td>
                    <td>
                        <?php 
                            if($status=='paid' && $delivery=='complete'){
                                $ul = urlencode($id);
                                ?> 
                                    <button class="bt1">Complete</button> 
                                    <a href="?del=<?php echo $id ?>"><button class="bt2">Delete</button></a>
                                <?php
                            }else{
                                ?> 
                                    <button class="bt3">Pending shipping</button> 
                                <?php 
                            }
                        ?>
                    </td>
                </tr>
            <?php
        }
    }
?>