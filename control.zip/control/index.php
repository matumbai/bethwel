<?php 
error_reporting(0);
session_start();
if($_SESSION['log']){
?>
<style>
    @charset "UTF-8";
    *{
        margin: 0px;
        padding: 0px;
    }
    body{
        margin: 0px; padding: 0px; font-size: 16px;
        background-color: #e0fdcd; background-image: linear-gradient(130deg,#e0fdcd,#abdef5);
        font-family: 'Arial Narrow Bold', sans-serif;cursor: default;
        -webkit-text-size-adjust: 100%;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    }
    .badge {
        display: inline-block;
        padding: 3px; padding-left: 10px;padding-right: 10px;
        font-size: 0.80em; font-weight: 600;color: #fff;
        text-align: center;white-space: nowrap;
        vertical-align: baseline;
        border-radius: 17px;
    }
    .main{
        padding: 0px;
        margin: 0px;
    }
    .navbar{
        width: 100%;
        background-color: green;
        padding: 10px;padding-right: 20px;
        position: fixed;
        color: white; top: 0px;
        background-image: linear-gradient(45deg, green, #50d403);
        box-shadow: 0 2px 2px blue;
        z-index: 10;
    }
    .main .content{
        margin-top: 47px;
        width: 100%;
        display: inline-flex;
    }
    .content .sidebar{
        width: 14%;
        height: 97%;
        padding: 7px;
        position: fixed;
        background-color: #f7faf5;
        box-shadow: 0 0 3px 3px green;
        /* background-image: url("icons/background.jpg"); */
        background-image: linear-gradient(-60deg, blue,green);
    }
    .sidebar h3{
        background-color: white;
        border-radius: 15px;
        padding: 5px;
        box-shadow: 0 0 5px 5px blue;
    }
    .sidebar ul{
        list-style: none;
    }
    .list{
        box-shadow: 0 0 5px 5px blue;
        background-color: white;
        padding: 5px;
        margin-top: 20px;
        border-radius: 10px;
    }
    .sidebar ul a{
        font-size: 17px;
        text-decoration: none;
        color: black;
    }
    .sidebar ul li{
        margin-left: 15px;
        margin-top: 20px;
    }
    .content .wrapper{
        margin-left: 15.5%;
        width: 84%;
    }
    .wrapper .dashboard{
        margin-top: 5px;
        width: 100%;
        display: inline-flex;
    }
    .navbar {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        padding-top: 0.5rem;
        padding-bottom: 0.5rem;
        }
    .dashboard .card{
        padding: 10px;background-color: white;margin: 5px;
        width: 30%; border-radius: 2px; box-shadow: 0 5px 5px green;
    }
    .dashboard img{
        width: 25px;height: 25px; margin-top: -30px;
        float: right;position: relative;border-radius: 5%;
    }
    .category{
        width: 30%;margin-top: 10px; background-color: white;
        box-shadow: 0 0 13px 13px green;
        position: fixed; z-index: 17; margin-left: 10px;
    }
    .category h4{
        padding: 5px;
    }
    .category input{
        width: 80%; padding: 5px; font-size: 16px; border: 1px solid grey;
        outline: none; margin-top: 10px;
    }
    .category button{
        padding: 5px; font-size: 16px; width: 60px;
    }
    .category .sect{
        background-color: white;
        padding: 7px; border: 1px solid #abdef5; width: 100%; padding: 5px;
    }
    .category .show{
        width: 100%; background-color: white;
        border: 1px solid #abdef5; padding: 5px;
    }
    .display{
        display: inline-flex;
        width: 100%;
    }
    .display .products{
        background-color: white; width: 49.3%;margin: 4px;padding: 5px; border-radius: 5px;
        z-index: 9; max-height: 450px;  overflow-y: auto; min-height: 200px;
        overflow-x: hidden; box-shadow: 0 10px 10px #0f9b02;
    }
    .display .products nav{
        margin-bottom: 7px; margin-left: -5px; z-index: 10;
        background-color: white; margin-top: -5px;
    }
    .display h3{
        padding-left: 10px;
        color: blue;
    }
    .display .customers{
        background-color: white;width: 49.3%; margin: 4px;
        padding: 5px; border-radius: 5px;z-index: 9; min-height: 100px;
        max-height: 450px;overflow-y: auto; padding-bottom: 20px; box-shadow: 0 10px 10px #0f9b02;
    }
    .products nav{
        display: inline-flex;width: 100%;padding: 4px;
        border-bottom: 2px solid blue; padding-bottom: 10px;
    }
    nav button{
        width: 60px; color: white; float: right;
        padding: 4px;background-color: blue; margin-left: 30px;
        border: none; border-radius: 5px; font-size: 16px;
    }
    .products form{
        top: 70px;
        width: 30%;
        padding: 7px;
        background-color: white;
        box-shadow: 0 0 10px 10px grey;
        margin: 10px;
        position: absolute;
        border-radius: 10px;
    }
    form h4{
        font-size: 22px;
        padding-bottom: 3px;
        color: blue;
        margin: 10px;
        border-bottom: 2px solid blue;
    }
    .products form input{
        height: 34px; width: 100%;outline: none;font-size: 16px;margin-top: 7px;
        border-radius: 17px;margin-bottom: 3px; border: none; padding-left: 15px; padding-right: 15px; box-shadow: 0 0 3px 3px #aff8a8;
    }
    form select{
        padding: 4px;font-size: 16px; min-width: 50%;border-radius: 17px;max-width: 100%;
        outline: none; padding-left: 15px;border: none;padding-right: 15px; box-shadow: 0 0 3px 3px #aff8a8;
    }
    form label{
        margin-bottom: 5px;
        font-size: 17px; font-weight: 500;
    }
    textarea{
        width: 100%; border: none; padding-left: 15px; padding-right: 15px;box-shadow: 0 0 3px 3px grey;
        border-radius: 5px; outline: none;font-size: 17px; margin-top: 10px; margin-bottom: 10px; font-family: 'Arial Narrow Bold', sans-serif;
        height: 70px;resize: none; max-height: 250px; padding-top: 10px; overflow-y: auto;
    }
    form button{
        background-color: blue; padding: 5px; border-radius: 7px;
        font-size: 16px; border: none;padding-top: 10px;
        width: 80px; text-align: center; color: white; margin:7px;
    }
    .sections{
        margin: 4px; background-color: white; padding: 4px; box-shadow: 0 3px 3px grey;
        border-bottom-left-radius: 10px; margin-bottom: 10px;
    }
    .sections img{
        width: 70px; margin-right: 17px;margin-left: 5px;
    }
    .sections h5{
        margin: 5px;font-size: 17px;
        font-weight: 500; text-decoration: underline;
    }
    .store p{
        color: green;margin-left: 10px; margin-right: 5px; font-size: 14px;
        font-weight: 500;
    }
    .sections button{
        width: 70px; padding: 4px; font-size: 15px; background-color: blue; border: none; border-radius: 3px;
        color: white; font-weight: 500;text-align: center;
    }
    .wrapper .section{
        display: inline-flex; width: 100%; margin-top: 10px;margin-bottom: 20px;
    }
    .section h3{
        color: blue;
        padding: 7px;
    }
    .wrapper .transactions{
        background-color: white; width: 48%; padding: 10px; margin-left: 3px;
        box-shadow: 0 2px 2px grey;border-radius: 7px; z-index: 3;
    }
    .wrapper .zones{
        background-color: white; width: 48%; padding: 10px;margin-left: 7px; z-index: 3;
        height: fit-content;box-shadow: 0 2px 2px grey; border-radius: 7px;
    }
    @media (min-width: 10px) and (max-width: 900px){
        .sidebar{
            display: none;
        }
        .main .wrapper{
            width: 100%; margin-left: 0px;
        }
        #dash .card img{
            display: none;
        }
        .display{
            width: 100%; height: fit-content;
            display: inline-block;
        }
        #my-form{
            width: 90%;
        }
        #edit-form{
            width: 90%;
        }
        .panel{
            width: 94%;
            padding-bottom: 50px;margin-bottom: 20px;
        }
        .display .products{
            width: 96%;
        }
        .display .customers{
            width: 96%;
        }
        .category{
            width: 98%;
        }
        .section .zones{
            width: 98%;height: fit-content;
        }
    }
</style>
<?php 
    include('../auth/conn.php');
?> 
<script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="../js/jquery.js"></script>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <style>
        .navbar a{
            text-decoration: none; color: white; font-size: 17px;
        }
    </style>
    <div class="main">
        <div class="navbar">
            <h3><a href="../index.php"><img src="../assets/120.png" width="25px"></a> Dashboard</h3>
            <img src="icons/list.svg" width="27px" id="cat1">
            <a href="?set"><img src="icons/settings.svg" width="27px"></a>
            <a href="?logout" style="float: right;margin-right: 27px;">Logout</a>
        </div>
        <?php 
            if(isset($_GET['logout'])){
                session_unset(); 
                session_destroy();
                session_write_close();
                header('Location: ../index.php');
            }
        ?>
        <div class="content">
            <div class="sidebar">
                <h3 style="text-align: center;">
                    <img src="icons/active.svg" style="width: 37px;height: 37px; border-radius: 40%; margin-left:-70px; position: absolute;">
                    Admin <br> Dashboard
                </h3>
                <ul class="list">
                    <h2>Menu</h2>
                    <a id="cats"><li><img src="icons/orders.jpg" width="27px" height="27px" style="margin-bottom: -7px;"> Categories</li></a>
                    <div style="margin-top: 17px; margin-bottom: 20px;">
                        <h4>Shop settings</h4>
                        <ul>
                            <li id="general">
                                <a href="?set"><img src="icons/general.png" width="25px" height="27px" style="margin-bottom: -10px;"> 
                                <span>General settings</span></a>
                            </li>
                        </ul>
                    </div>
                </ul>
                <script>
                    // categories
                    $('#cats').click(function(){
                        $('.category').slideToggle(10);
                        $('.settings').hide(10);
                    })
                    $('#cat1').click(function(){
                        $('.category').slideToggle(10);
                        $('.settings').hide(10);
                    })
                </script>
            </div>
            <div class="wrapper">
                <div class="dashboard" id="dash">
                    <div class="card">
                        <h4 style="color: #579461;font-size: 22px;margin-bottom: 5px;">Orders</h4>
                        <?php 
                            $empty = "";
                            $calc = mysqli_query($conn, "SELECT count(*) id FROM orders WHERE delivery='$empty'");
                            $find = mysqli_query($conn, "SELECT SUM(price*quantity) as cash FROM orders");
                            $e = mysqli_fetch_assoc($find);
                            $cash =$e['cash'];
                            // count pending orders
                            $el = mysqli_fetch_assoc($calc);
                            $num =$el['id'];
                        ?>
                        <b>Ksh: <?php echo $cash ?></b> 
                        <?php 
                        if($num>0){
                        ?><span class="badge" style="background-color: green;float:right;"><?php echo $num." "."Pending"; ?></span> <?php
                        }
                        ?>
                        <img src="icons/basket.png" width="45px" height="45px">
                    </div>
                    <div class="card">
                        <h4 style="color: #075dfc;font-size: 22px;margin-bottom: 5px;">Products</h4>
                        <?php 
                            $find = mysqli_query($conn, "SELECT count(*) id, SUM(price) as total FROM products");
                            $e = mysqli_fetch_assoc($find);
                            $pro =$e['id'];
                            $total =$e['total'];
                        ?>
                        <b style="color: #043ca3;margin:5px;"><?php if($pro>1){ echo $pro." ". "items";}else{ echo $pro." ". "items";} ?>
                        <span style="float: right;color:#abdef5;">Ksh: <?php echo $total?></span>
                        </b>
                        <img src="icons/rocket.svg" width="45px" height="45px">
                    </div>
                    <div class="card">
                        <h4 style="color: #fd0194;font-size: 22px;">Customers</h4>
                        <?php 
                            $find = mysqli_query($conn, "SELECT count(*) id FROM orders GROUP BY name");
                            $e = mysqli_fetch_assoc($find);
                            $cu =$e['id'];
                        ?>
                        <b style="color: #50d403;"><?php if($cu>1){ echo $cu." ". "customers";}else{ echo $cu." ". "customer";} ?></b>
                        <img src="icons/Up.png" width="45px" height="45px">
                    </div>
                </div>
                <!-- categories -->
                <div class="category" style="display: none;">
                    <div class="sect">
                        <div class="add">
                            <h4>Add categories</h4>
                            <div class="info"></div>
                            <input type="text" id="new_category" name="category" placeholder="Add category..">
                            <button id="post_data_category">Post</button>
                            <script>
                                $('#post_data_category').click(function(){
                                    var type = "category";
                                    var category = $('#new_category').val();
                                    $.ajax({
                                        url: "category.php",
                                        method: "post",
                                        data: {type, category},
                                        success: function(data){
                                            $('#new_category').val('');
                                            $('.info').html(data);
                                        }
                                    })
                                })
                            </script>
                        </div>
                    </div>
                    <div class="show">
                        <h3>All categories</h3>
                        <div class="all_List"></div>
                        <script>
                            setInterval(function(){
                                category();
                            },700)
                            function category(){
                                var type = "display_category";
                                $.ajax({
                                    url: "category.php",
                                    method: "post",
                                    data: {type:type},
                                    success: function(data){
                                        $('.all_List').html(data);
                                    }
                                })
                            }
                        </script>
                    </div>
                </div>
                <div class="settings">
                    <?php 
                    // settings
                    if(isset($_GET['set'])){
                    include('set.php'); 
                    }
                    ?>
                </div>
                <div class="edit">
                    <?php 
                        include('edit.php');
                    ?>
                </div>
                <!-- display -->
                <div class="display">
                    <div class="products">
                        <nav>
                            <h3>My Products</h3>
                            <button id="open">Sell</button>
                            <script>
                                // frm
                                $('#open').click(function(){
                                    $('#my-form').slideToggle(1);
                                })
                            </script>
                        </nav>
                        <form action="insert.php" id="my-form" method="post" style="display: none;">
                            <span style="border-radius: 17px; padding: 5px;float: right; background-color: #fd0194;
                            width: 60px; color: white; text-align: center;" id="zit">Exit</span>
                            <h4>Upload products</h4>
                            <div class="action-er"></div>
                            <input type="text" name="product" placeholder="Product name.." autocomplete="off"><br><br>
                            <label for="upload-file"> Upload product image <span style="border-radius: 5px;height: 30px;background-color: blue; color: white;padding: 4px;">Upload</span></label>
                            <input type="file" id="upload-file" name="image" style="display: none;"><br><br>
                            <input type="number" name="price" placeholder="Enter your price..">
                            <input type="text" name="weight" placeholder="Quantity eg 1kg..">
                            <input type="text" name="stock" placeholder="Items in stock..">
                            <label style="margin-bottom: 10px;">Select category:</label><br><br>
                            <select name="category" id="">
                                <option value="">Category name</option>
                                <?php 
                                    $sq = "SELECT category FROM main";
                                    $re = mysqli_query($conn, $sq);
                                    while($roe=mysqli_fetch_assoc($re)){
                                        $ca = $roe['category'];
                                        ?> <option value="<?php echo $ca ?>"><?php echo $ca ?></option> <?php
                                    }
                                ?>
                            </select>
                            <textarea name="description" id="" placeholder="Product description.."></textarea>
                            <button type="button" id="pass-product">Submit</button>
                        </form> 
                        <script>
                            $('#pass-product').click(function(){
                                var form = $('#my-form')[0];
                                var content = new FormData(form);
                                $.ajax({
                                    method: "post",
                                    url: "insert.php", data: content,
                                    processData: false, contentType: false,
                                    cache: false, async: false,
                                    beforeSend: function(){
                                        $('.action-er').html("<p style='color: blue;'>Uploading...</p>");
                                    },
                                    success: function(data){
                                        $('.action-er').html(data);
                                    }
                                })
                            })
                            // exit
                            $('#zit').click(function(){
                                $('#my-form').hide(1);
                            })
                            $("textarea").keyup(function(e) {
                                $(this).height(70);
                                $(this).height(this.scrollHeight + parseFloat($(this).css("borderTopWidth")) + parseFloat($(this).css("borderBottomWidth")));
                            });
                        </script>
                        <!-- product list -->
                        <div class="display-products">
                            <table>
                                <thead>
                                    <tr>
                                        <td>Product</td>
                                        <td>Details</td>
                                        <td>Action</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $qry="SELECT * FROM products ORDER BY date, items DESC";
                                        $results = mysqli_query($conn, $qry);
                                        $row = mysqli_num_rows($results);
                                        if(!$row>0){
                                            echo "<p style='text-align: center;margin: 20px;font-size: 20px; color: red;'>No products found!</p>";
                                        }else{
                                            while($row = mysqli_fetch_assoc($results)){
                                                $product =$row['product'];
                                                $image =$row['image'];
                                                $text = $row['description'];
                                                $description = str_replace('\r\n', "</br>", $text);
                                                $price =$row['price'];
                                                $quantity = $row['quantity'];
                                                $items = $row['items'];
                                                ?>
                                                    <tr class="sections">
                                                        <td>
                                                            <h5><?php echo $product?></h5>
                                                            <img src="../products/<?php echo $image?>" width="45px" style="margin-bottom: 7px;">
                                                        </td>
                                                        <td>
                                                            <b>Ksh: <?php echo $price?></b> 
                                                            <span class="store"><?php 
                                                                if($items>0){
                                                                    echo "<p>$items in stock </p>";
                                                                }else{
                                                                    echo "<p style='color: #df0484;'>Sold out! </p>";
                                                                }
                                                            ?></span>
                                                            <span><?php echo $quantity ?></span>
                                                        </td>
                                                        <td>
                                                            <a href="index.php?update=<?php echo $product ?>"><button>Update</button></a>
                                                            <a href="index.php?delete=<?php echo $product ?>"><button style="background-color: #FF046C;">Delete</button></a>
                                                        </td>
                                                    </tr>
                                                <?php
                                            };
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                     <!-- customers -->
                    <div class="customers">
                        <h3>My customers</h3>
                        <style>
                            .customers button{
                                padding: 4px;
                                border-radius: 5px;
                                color: white;
                                border: none; min-width: 60px;
                                font-size: 16px;
                            }
                            .bt1{
                                background-color: green;
                            }
                            .bt2{
                                background-color: #FF046C;
                            }
                            .bt3{
                                background-color: blue;
                            }
                        </style>
                        <table>
                            <thead>
                                <tr>
                                    <td>Customer</td>
                                    <td>Details</td>
                                    <td>Location</td>
                                    <td>Shipping</td>
                                </tr>
                            </thead>
                            <tbody id="results">
                                <script>
                                    setInterval(function(){
                                        sales();
                                    },700);
                                    function sales(){
                                        $.ajax({
                                            method: "post",
                                            url: "orders.php",
                                            success: function(data){
                                                $('#results').html(data)
                                            }
                                        })
                                    }
                                </script>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- transactions -->
                <div class="section">
                    <div class="zones">
                        <h3>Marketing regions</h3>
                        <div class="region">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <td><b> County</b></td>
                                        <td><b> Constituencies</b></td>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
                                    $sql = "SELECT id, county FROM regions GROUP BY county";
                                    $res = mysqli_query($conn, $sql);
                                    while($row = mysqli_fetch_assoc($res)){
                                        $id = $row['id'];
                                        $county = $row['county'];
                                        ?> 
                                            <tr>
                                                <td><?php echo $county ?></td>
                                                <td>
                                                    <?php 
                                                        $county1 = htmlentities(mysqli_real_escape_string($conn, $county));
                                                        $sql = "SELECT constituency FROM regions WHERE county='$county1' ORDER BY constituency";
                                                        $out = mysqli_query($conn, $sql);
                                                        while($ro = mysqli_fetch_array($out)){
                                                            $const = $ro['constituency'];
                                                            ?><li><?php echo $const ?></li> <?php
                                                        }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php
                                    }
                                ?>
                                </tbody>
                            </table>
                        </div>
                        <style>
                            .region{
                                height: 300px;
                                overflow-y: auto;
                                overflow-x: hidden;
                            }
                            table{
                                width: 100%;
                                border-collapse: collapse;
                            }
                            table thead tr{
                                font-size: 1em;
                                background-color: #009879;
                                text-align: left;
                                color: white;
                            }
                            thead tr td{
                                padding: 7px;
                            }
                            thead tr td:nth-of-type(1){
                                border-top-left-radius: 10px;
                            }
                            thead tr td:nth-last-of-type(1){
                                border-top-right-radius: 10px;
                            }
                            tbody tr{
                                border-bottom: 1px solid #009879;
                                padding: 4px;
                            }
                            tbody td{
                                padding: 4px;
                                padding-left: 10px;
                                margin: none;
                            }
                        </style>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php
}else{
   ?>
    <center><p style="color: #fd0194;margin-top: 50px;">404 error! Direct access denied!</p> 
        <a href="../index.php" style="color: blue;text-decoration: none;"><h4> Back to shop</h4></a></center>
   <?php
}
?>