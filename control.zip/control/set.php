<style>
    .panel{
        background-color: white; font-family: Verdana, Geneva, Tahoma, sans-serif; border-radius: 7px;
        position: fixed;width: 40%; z-index: 20;box-shadow: 0 0 50px grey;padding: 10px;top: 65px;max-height: 90%;
        overflow-y: auto;
    }hr{
        margin: 5px;
    } .panel textarea{
        box-shadow: none; border: 1px solid grey; overflow-y: hidden;
    }.inp{
        padding: 5px;font-size: 16px;margin: 5px; border-radius: 1px; border: 1px solid grey;

    }
    label b{color: #01318a;
        margin-bottom: 7px;
    }
</style>
<div class="panel">
    <a href="index.php" style="float: right;"><b>Close</b></a>
    <h3>General settings</h3>
    <?php 
        $res = mysqli_query($conn, "SELECT * FROM about");
        $row = mysqli_fetch_assoc($res);
        $shop = $row['shop'];
        $tel = $row['tel'];
        $logo = $row['logo'];
    ?>
    <form id="pro-file" method="post" style="margin-bottom: 20px;" enctype="multipart/form-data">
        <h4>Shop profile</h4>
        <div class="filt1"></div><div class="filt"></div>
        <label><b> Shop name:</b></label><br>
        <input class="inp" type="text" name="name" value="<?php echo $shop ?>" placeholder="Shop name.."><br>
        <label><b> Shop tel:</b></label><br>
        <input class="inp" type="number" name="tel"value="<?php echo $tel ?>" placeholder="Shop tel.."><br>
        <label for="logo">Update Logo:</label>
        <input type="file" name="logo" id="logo"><br>
        <?php 
            if(!empty($logo)){
                ?><img src="../assets/<?php echo $logo ?>" width="100px"><?php
            }
        ?>
        <input type="text" name="pro" value="<?php echo $logo ?>" style="display: none;"><br>
        <button id="post1" type="submit">Update</button>
    </form><hr>
    <script>
        $('#post1').click(function(event){
            event.preventDefault();
            var form = $('#pro-file')[0];
            var content = new FormData(form);
            $.ajax({   method: "post",  enctype: 'multipart/form-data',
                url: "function.php", data: content,  
                processData: false, contentType: false,
                beforeSend:function(){
                    $('.filt1').html('<img src="icons/loading.gif">');
                }, success:function(data){
                    $('.filt').html(data);
                    $('.filt1').html('');
                }
            });
        })
    </script>
    <?php 
    $res = mysqli_query($conn, "SELECT * FROM content");
    $row = mysqli_fetch_assoc($res);
    $image = $row['banner'];
    $tittle = $row['tittle'];
    $desc = $row['description'];
    ?>
    <form id="banners" method="post" style="margin-top: 20px;" enctype="multipart/form-data">
        <h4>Shopping Page content</h4>
        <div class="ban"></div><div class="st"></div>
        <?php 
        if(!empty($image)){
            ?><img src="../assets/<?php echo $image ?>" width="100px"> <?php
        }
        ?>
        <label for="ban">Update image banner: <img src="../assets/image.svg" width="25px" style="margin-bottom: -7px;"></label><br>
        <input id="ban" type="file" name="file" style="display: none;"><br>

        <label><b> Page tittle:</b></label><br>
        <input name="header" class="inp" value="<?php echo $tittle ?>" placeholder="Shop tittle tags.."><br>
        <label><b> Shop description:</b></label><br>
        <textarea name="des" placeholder="Short description"><?php echo $desc ?></textarea>
        <button id="saves" type="submit">Update</button>
    </form>
    <script>
        $('#saves').click(function(event){
            event.preventDefault();
            var form = $('#banners')[0];
            var content = new FormData(form);
            $.ajax({   method: "post",  enctype: 'multipart/form-data',
                url: "function.php", data: content,  
                processData: false, contentType: false,
                beforeSend:function(){
                    $('.st').html('<img src="icons/loading.gif">');
                }, success:function(data){
                    $('.ban').html(data);
                    $('.st').html('');
                }
            });
        })
    </script>
</div>