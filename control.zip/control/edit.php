<style>
    .updator{
        position: fixed;
        top: 60px;
        z-index: 20;
        padding: 10px;
        width: 100%;
    }
    .updator form{
        width: 30%;
        background-color: white;
        padding: 5px; padding-top: 10px;
        padding-bottom: 10px;
        box-shadow: 0 10px 10px grey;
        border-bottom-right-radius: 7px;
        border-bottom-left-radius: 7px;
    }
    .updator label{
        font-weight: 600;
    }
    .updator input{
        height: 34px;
        width: 100%;
        outline: none;
        font-size: 16px;
        margin-top: 7px;
        border-radius: 17px;
        margin-bottom: 3px;
        border: none;
        padding-left: 15px;
        padding-right: 15px;
        box-shadow: 0 0 3px 3px #aff8a8;
    }
    .alert{
        background-color: white;
        padding: 7px;
        width: fit-content;
        box-shadow: 0 10px 10px grey, 0 0 2px 2px green;
        border-radius: 5px;
    }
    .alert h3{
        color: blue;
        text-decoration: 2px solid underline;
        margin-bottom: 10px;
    }
    .text-success{
        color: green;
        margin: 5px;
    }
    .alert button{
        padding: 5px;
        border-radius: 5px;
        margin-top: 7px;
        font-size: 15px;
        background-color: blue;
        min-width: 70px; color: white;
        border: none;
    }
</style>
<div class="updator">
    <?php 
        if(isset($_GET['update'])){
            $update = htmlspecialchars(mysqli_real_escape_string($conn, $_GET['update']));
            $sel = "SELECT * FROM products WHERE product='$update' LIMIT 1";
            $results = mysqli_query($conn, $sel);
            while($row = mysqli_fetch_assoc($results)){
                $product = $row['product'];
                $image = $row['image'];
                $text = $row['description'];
                $description = str_replace('\r\n', "</br>", $text);
                $price = $row['price'];
                $category = $row['category'];
                $quantity = $row['quantity'];
                $items = $row['items'];
                ?>
                    <form action="update.php" id="edit-form" method="post">
                        <a href="index.php"><span style="border-radius: 17px; padding: 5px;float: right; background-color: #fd0194;
                        width: 60px; color: white; text-align: center;" id="x-zit">Exit</span></a>
                        <h4>Update products</h4>
                        <div class="action-er1"></div>
                        <input type="text" name="product" placeholder="Product name.." autocomplete="off" value="<?php echo $product ?>"><br><br>
                        <label for="upload-file1"> Update product image <span style="font-weight: 500; border-radius: 5px;height: 30px;background-color: blue; color: white;padding: 4px;">Upload</span></label>
                        <input type="file" id="upload-file1" name="image" style="display: none;"><br><br>
                        <label style="margin-bottom: 10px;">Price:</label><br>
                        <input type="number" name="price" placeholder="Enter your price.." value="<?php echo $price ?>">
                        <label style="margin-bottom: 10px;">Quantity:</label><br>
                        <input type="text" name="weight" placeholder="Quantity eg 12kg.." value="<?php echo $quantity ?>">
                        <input type="text" name="images" value="<?php echo $image ?>" style="display: none;">
                        <label style="margin-bottom: 10px;">Items:</label><br>
                        <input type="text" name="stock" placeholder="Items in stock.."  value="<?php echo $items ?>">
                        <label style="margin-bottom: 10px;">Select category:</label><br><br>
                        <select name="category" id="">
                            <option value="<?php echo $category ?>"><?php echo $category ?></option>
                            <?php 
                                $sq = "SELECT category FROM main";
                                $re = mysqli_query($conn, $sq);
                                while($roe=mysqli_fetch_assoc($re)){
                                    $ca = $roe['category'];
                                    ?> <option value="<?php echo $ca ?>"><?php echo $ca ?></option> <?php
                                }
                            ?>
                        </select><br>
                        <label style="margin-bottom: 10px;">Description:</label><br>
                        <textarea name="description" id="" placeholder="Product description.."><?php echo $description ?></textarea>
                        <button type="button" id="Update-product">Update</button>
                    </form>
                    <script>
                        $('#Update-product').click(function(){
                            var form = $('#edit-form')[0];
                            var content = new FormData(form);
                            $.ajax({
                                method: "post",
                                url: "update.php", data: content,
                                processData: false, contentType: false,
                                cache: false, async: false,
                                beforeSend: function(){
                                    $('.action-er1').html("<p style='color: blue;'>Uploading...</p>");
                                },
                                success: function(data){
                                    $('.action-er1').html(data);
                                }
                            })
                        })
                        // exit
                        $('#x-zit').click(function(){
                            $('#edit-form').hide(1);
                        })
                        $("textarea").keyup(function(e) {
                            $(this).height(70);
                            $(this).height(this.scrollHeight + parseFloat($(this).css("borderTopWidth")) + parseFloat($(this).css("borderBottomWidth")));
                        });
                    </script>
                <?php
            }
        }
        // delete order
        if(isset($_GET['del'])){
            $del = $_GET['del'];
            ?>
                <div class="alert">
                    <h3>Delete order</h3>
                    <p>Are you sure you want to delete this order history</p>
                    <div class="err"></div>
                    <form action="delete.php" id="delete_form" method="post" style="display: none;">
                        <input type="text" name="name" value="<?php echo $del ?>">
                    </form>
                    <button id="confirm_del">Confirm</button> <a href="index.php"><button style="background-color: #fd0194;">Close</button></a>
                    <script>
                        $('#confirm_del').click(function(){
                            $.ajax({
                                url: "del_ord.php",
                                method: "post",
                                data: $('#delete_form').serialize(),
                                success: function(data){
                                    $('.err').html(data)
                                }
                            })
                        })
                    </script>
                </div>
            <?php 
        }
        // delete file
        if(isset($_GET['delete'])){
            $del = $_GET['delete'];
            ?>
                <div class="alert">
                    <h3>Delete product</h3>
                    <p>Are you sure you want to delete this product?</p>
                    <div class="err"></div>
                    <form action="delete.php" id="delete_form" method="post" style="display: none;">
                        <input type="text" name="name" value="<?php echo $del ?>">
                        <?php 
                            $sel = "SELECT image FROM products WHERE product='$del' LIMIT 1";
                            $results = mysqli_query($conn, $sel);
                            $ro = mysqli_fetch_assoc($results);
                            $image_del = $ro['image']; 
                        ?>
                        <input type="text" name="image" value="<?php echo $image_del ?>">
                    </form>
                    <button id="confirm_del">Confirm</button> <a href="index.php"><button style="background-color: #fd0194;">Close</button></a>
                    <script>
                        $('#confirm_del').click(function(){
                            $.ajax({
                                url: "delete.php",
                                method: "post",
                                data: $('#delete_form').serialize(),
                                success: function(data){
                                    $('.err').html(data)
                                }
                            })
                        })
                    </script>
                </div>
            <?php 
        }
    ?>
</div>