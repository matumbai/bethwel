<style>
    .text-danger{
        margin: 4px;
        color: #ff0080;
        text-align: center;
    }
</style>
<?php
    include('../auth/conn.php');
    $product = htmlentities(mysqli_real_escape_string($conn, $_POST['product']));
    $price = htmlentities(mysqli_real_escape_string($conn, $_POST['price']));
    $quantity = htmlentities(mysqli_real_escape_string($conn, $_POST['weight']));
    $items = htmlentities(mysqli_real_escape_string($conn, $_POST['stock']));
    $category = htmlentities(mysqli_real_escape_string($conn, $_POST['category']));
    $description = htmlentities(mysqli_real_escape_string($conn, $_POST['description']));
    if(!empty($product) && !empty($price) && !empty($quantity) && !empty($items) && !empty($category) && !empty($description)){
        // check duplicate
        $check = "SELECT product FROM products WHERE product='$product'";
        $re = mysqli_query($conn, $check);
        $row = mysqli_num_rows($re);
        if($row>0){
            echo "<p class='text-danger'>Product name already exists!</p>";
        }else{
            // upload product
            if(!empty($_FILES["image"]["name"])){
                $fileInfo = PATHINFO($_FILES["image"]["name"]);
                if ($fileInfo['extension'] == "jpg" OR $fileInfo['extension'] == "png") {
                    $newFilename = $fileInfo['filename'] . "_" . time() . "." . $fileInfo['extension'];
                    move_uploaded_file($_FILES["image"]["tmp_name"], "../products/" . $newFilename);
                    $image = htmlspecialchars(mysqli_real_escape_string($conn, $newFilename));
                }
                // insert data
                $sql = "INSERT INTO products(product,image,category,description,price,quantity,items)
                VALUES('$product','$image','$category','$description','$price','$quantity','$items')";
                $result = mysqli_query($conn, $sql);
                if($result){
                    ?> <script> $('#my-form').trigger('reset'); </script> <?php
                }
            }else{
                ?> <span class="text-danger">You must upload product image!</span> <?php
            }
        }
    }else{
        ?> <span class="text-danger">All fields must be filled!</span> <?php
    }

    
?>