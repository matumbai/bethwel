<?php 
// code like a star tel: 0768570552
include('../auth/conn.php');
// set shop profile
if(isset($_POST['pro'])){
    $tel = htmlentities(mysqli_real_escape_string($conn, $_POST['tel']));
    $name = htmlentities(mysqli_real_escape_string($conn, $_POST['name']));
    $logo = $_FILES['logo']['name'];
    $sq = mysqli_query($conn, "SELECT * FROM about");
    $r = mysqli_num_rows($sq);
    if(!$r>0){
        if(!empty($tel) || !empty($name)){
            if(!empty($logo)){
                $fileInfo = PATHINFO($_FILES["logo"]["name"]);
                if($fileInfo['extension'] == "jpg" OR $fileInfo['extension'] == "png" OR $fileInfo['extension'] == "jpeg") {
                    $newFilename = $fileInfo['filename'] . "_" . time() . "." . $fileInfo['extension'];
                    $img = $newFilename;
                    move_uploaded_file($_FILES["logo"]["tmp_name"], "../assets/". $newFilename);
                    // insert data
                    $insert = mysqli_query($conn, "INSERT INTO about(shop,logo,tel) VALUES('$name','$img','$tel') ");
                }else{
                    ?> <p style="color: red;">Only images allowed!</p> <?php
                }
            }else{
                ?> <p style="color: red;">Please upload logo!</p> <?php
            }
        }else{
            ?> <p style="color: red;">All fields required!</p> <?php
        }
    }else{
        if(!empty($tel) || !empty($name)){
            if(!empty($logo)){
                $f=$_POST['pro'];
                unlink("../assets/$f"); //delete existing file
                $fileInfo = PATHINFO($_FILES["logo"]["name"]);
                if($fileInfo['extension'] == "jpg" OR $fileInfo['extension'] == "png" OR $fileInfo['extension'] == "jpeg") {
                    $newFilename = $fileInfo['filename'] . "_" . time() . "." . $fileInfo['extension'];
                    $img = $newFilename;
                    move_uploaded_file($_FILES["logo"]["tmp_name"], "../assets/". $newFilename);
                    // update data
                    $UPDATE = mysqli_query($conn, "UPDATE about SET shop='$name', logo='$img',tel='$tel' ");
                }else{
                    ?> <p style="color: red;">Only images allowed!</p> <?php
                }
            }else{
                $UPDATE = mysqli_query($conn, "UPDATE about SET shop='$name',tel='$tel' ");
            }
        }else{
            ?> <p style="color: red;">All fields required!</p> <?php
        }
    }
}
// Set shop content and banner
if(isset($_POST['des'])){
    $content = htmlentities(mysqli_real_escape_string($conn, $_POST['des']));
    $ttl = htmlentities(mysqli_real_escape_string($conn, $_POST['header']));
    $banner = $_FILES['file']['name'];
    if(!empty($banner)){
        $fileInfo = PATHINFO($_FILES["file"]["name"]);
        if($fileInfo['extension'] == "jpg" OR $fileInfo['extension'] == "png" OR $fileInfo['extension'] == "jpeg") {
            $newFilename = $fileInfo['filename'] . "_" . time() . "." . $fileInfo['extension'];
            $img = $newFilename;
            move_uploaded_file($_FILES["file"]["tmp_name"], "../assets/". $newFilename);
            //update data
            $UPDATE = mysqli_query($conn, "UPDATE content SET banner='$img', tittle='$ttl', description='$content' ");
        }else{
            ?> <p style="color: red;">Only images allowed!</p> <?php
        }
    }else{
        $UPDATE = mysqli_query($conn, "UPDATE content SET tittle='$ttl', description='$content' ");
    }
}
if(isset($_POST['de_ca'])){
    $id = $_POST['id'];
    $DELETE = mysqli_query($conn, "DELETE FROM main WHERE id='$id' ");
}
?>