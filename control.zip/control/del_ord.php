<?php 
include('../auth/conn.php');
$id = $_POST['name'];
$del =mysqli_query($conn, "DELETE FROM orders WHERE id='$id'");
if($del){
    ?> <p style="color: green;">Order deleted successfully!</p> <?php
}
?>