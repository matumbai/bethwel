<style>
    .c-li{
        border-bottom: 1px solid #edf3ee;
    }
</style>
<?php 
    include('../auth/conn.php');
    $type = $_POST['type'];
    // insert category
    if($type=="category"){
        $category = htmlentities(mysqli_real_escape_string($conn, $_POST['category']));
        // check duplicate
        $see = "SELECT * FROM main WHERE category='$category'";
        $out = mysqli_query($conn, $see);
        $row = mysqli_num_rows($out);
        if(!$row>0){
            if(!empty($category)){
                $sql = "INSERT INTO main(category) VALUES('$category')";
                $res = mysqli_query($conn, $sql);
                if($res){
                    echo "<p style='color: #026607;'>Upload complete!</p>";
                }
            }else{
                echo "<p style='color: #f83556;'>Please enter valid category!</p>";
            }
        }else{
            echo "<p style='color: #f83556;'>Category already Exists!</p>";
        }
    }// insert sub category
    elseif($type=="display_category"){
        $sq = "SELECT * FROM main";
        $request = mysqli_query($conn, $sq);
        while($find = mysqli_fetch_assoc($request)){
            $categoryList = $find['category'];
            ?> <div class="c-li c<?php echo $find['id'] ?>" style="margin-top: 5px; width: 100%;"><?php echo $categoryList ?> 
                <button style="height: 26px; float: right;margin-top: -13px;">Delete</button>
                <script>
                    $('.c<?php echo $find['id'] ?>').click(function(){
                        var de_ca = "category";
                        var id = "<?php echo $find['id'] ?>";
                        $.ajax({
                            url: "function.php",
                            method: "post",
                            data: {de_ca, id},
                            success: function(data){
                                $('.c<?php echo $find['id'] ?>').hide();
                            }
                        })
                    })
                </script>
            </div> <br><?php
        }
    }
    // display categories
?>